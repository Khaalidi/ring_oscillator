#include <stdio.h>
#include "platform.h"
#include "xil_printf.h"
#include "xgpio.h"
#include "xparameters.h"
#include "sleep.h"

#define MAX_ROUNDS 10

void prettyPrint(int data[]);

int main()
{
    init_platform();

    XGpio data_channel, control_channel;

    int data[MAX_ROUNDS];

    // AXI for the counter
    XGpio_Initialize(&data_channel,XPAR_AXI_GPIO_0_DEVICE_ID);
    XGpio_SetDataDirection(&data_channel, 1,1);

    // AXI for Resetting the FSM and the registers
    XGpio_Initialize(&control_channel, XPAR_AXI_GPIO_1_DEVICE_ID);
    XGpio_SetDataDirection(&control_channel, 1,0);
    XGpio_DiscreteWrite(&control_channel,1,0x0);


    for (int r = 0; r<MAX_ROUNDS; r++)
    {
        data[r] = XGpio_DiscreteRead(&data_channel,1);
        XGpio_DiscreteWrite(&control_channel,1,0x1);
        usleep(1);
        XGpio_DiscreteWrite(&control_channel,1,0x0);
        usleep(1000);
    }

    prettyPrint(data);


    cleanup_platform();
    return 0;
}


//  Print the array to the serial in a format  easily split by the Python Script
//  b'298429+298233+298274+298293+298284+298195+298293+298271+298272+298314\r\n'

void prettyPrint(int data[])
{
	for (int r=0; r<MAX_ROUNDS; r++)
	{
		printf("%d", data[r]);
		if (r < MAX_ROUNDS-1)
		{
			printf("+");
		}
		else
		{
			printf("\n");
		}
	}
}
